<div class="row">
    <div class="col-12 text-center">
        <div class="my-5">
            <h1 class="h3 text-danger"><strong>404</strong> Page not found!</h1>
            <h3 class="h4 text-secondary">The page you want to access was not found.</h3>
        </div>
    </div>
</div>